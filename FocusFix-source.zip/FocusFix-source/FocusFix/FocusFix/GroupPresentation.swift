import Foundation
import CoreGraphics

// Presentation state contains only the selected group ID and metric, never member data.
enum LeaderboardMetric: String, Codable, CaseIterable, Identifiable {
    case work, habits
    var id: String { rawValue }
    var title: String { self == .work ? "Work streak" : "Healthy habits" }
    var scoreTitle: String { self == .work ? "DAY STREAK" : "DAY STREAK" }
    var explanation: String {
        self == .work ? "Current streaks since joining: 60 minutes of declared work earns a day. Completed weekends count too; missed weekends are optional. An unprotected missed weekday resets the streak to 0." : "Current streaks since joining: a completed 1-minute break earns a day. Completed weekends count too; missed weekends are optional. An unprotected missed weekday resets the streak to 0."
    }
    func score(_ member: SocialMember) -> Int { self == .work ? (member.workStreak ?? 0) : (member.habitsStreak ?? 0) }
    func rank(_ member: SocialMember) -> Int { self == .work ? (member.workStreakRank ?? 0) : (member.habitsStreakRank ?? 0) }
    func sorted(_ members: [SocialMember]) -> [SocialMember] {
        members.sorted {
            if score($0) != score($1) { return score($0) > score($1) }
            if $0.name != $1.name { return $0.name < $1.name }
            return $0.id.uuidString < $1.id.uuidString
        }
    }
}

enum PodiumPlace: Int, CaseIterable {
    case first = 1, second, third
    init?(rank: Int, score: Int) {
        guard score > 0, let value = Self(rawValue: rank) else { return nil }
        self = value
    }
    var title: String {
        switch self { case .first: return "First place"; case .second: return "Second place"; case .third: return "Third place" }
    }
}

struct GroupSelection: Codable, Equatable {
    var groupID: UUID?
    var metric: LeaderboardMetric = .work
    mutating func reconcile(groups: [SocialGroup]) {
        if !groups.contains(where: { $0.id == groupID }) { groupID = groups.first?.id }
    }
}

enum GroupAccessState: Equatable {
    case signedOut, disabled, loading, enabled, offline, unavailable
    static func resolve(signedIn: Bool, enabled: Bool, busy: Bool, loaded: Bool, failed: Bool, notice: Bool) -> Self {
        if !signedIn { return .signedOut }
        if !enabled { return notice ? .unavailable : .disabled }
        if failed { return .offline }
        if busy && !loaded { return .loading }
        return .enabled
    }
}

// Groups and Analytics occupy the same expansion slot, including the sheet fallback.
enum CollectorPanel: String, Identifiable {
    case groups, analytics
    var id: String { rawValue }
}

struct CollectorPanelSelection {
    var expanded: CollectorPanel?
    var sheet: CollectorPanel?

    mutating func toggle(_ panel: CollectorPanel, canExpand: Bool) {
        if expanded == panel || sheet == panel { close(); return }
        expanded = canExpand ? panel : nil
        sheet = canExpand ? nil : panel
    }
    mutating func close() { expanded = nil; sheet = nil }
    mutating func adapt(canExpand: Bool) {
        guard !canExpand, let panel = expanded else { return }
        expanded = nil
        sheet = panel
    }
}

struct PeopleWindowLayout {
    static let compactWidth: CGFloat = 490
    static let panelWidth: CGFloat = 359
    static let expandedWidth: CGFloat = 850
    static func canExpand(in visibleFrame: CGRect) -> Bool { visibleFrame.width >= expandedWidth }
    static func clampedFrame(current: CGRect, expanded: Bool, visible: CGRect) -> CGRect {
        let width = min(expanded ? expandedWidth : compactWidth, visible.width)
        let height = min(current.height, visible.height)
        return CGRect(x: min(max(current.minX, visible.minX), visible.maxX - width),
                      y: min(max(current.minY, visible.minY), visible.maxY - height), width: width, height: height)
    }
}
