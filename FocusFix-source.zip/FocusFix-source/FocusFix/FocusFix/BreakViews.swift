// MARK: - FF: BREAKS
// Displays break choices, duration presets, optional activity correction and current reminder controls.

import SwiftUI

// Turn elapsed seconds into a readable hours:minutes:seconds label.
func durationText(_ seconds: Double) -> String {
    let value = Int(max(0, seconds).rounded(.up))
    return String(format: "%02d:%02d:%02d", value / 3600, value / 60 % 60, value % 60)
}

struct BreakActivityPicker: View {
    static let options = ["Stretch", "Walk", "Water / snack", "Rest my eyes", "Breathing", "Other"]
    @Binding var selection: String
    @Binding var custom: String
    // Show common break activities and a short custom option.
    var body: some View {
        Picker("Activity", selection: $selection) {
            ForEach(Self.options, id: \.self) { Text($0).tag($0) }
        }
        if selection == "Other" {
            TextField("What would you like to do?", text: $custom)
                .textFieldStyle(.roundedBorder)
                .onChange(of: custom) { _, value in custom = String(value.prefix(120)) }
        }
    }
}

struct BreakSetupView: View {
    @ObservedObject var tracker: ActivityTracker
    @Environment(\.dismiss) private var dismiss
    @State private var preset = 5
    @State private var customMinutes = "5"
    @State private var activity = "Stretch"
    @State private var customActivity = ""
    @State private var fatigue: Int?
    @State private var productivity: Int?
    @State private var contentHeight: CGFloat = 320
    // Read either a preset duration or the typed custom minutes.
    private var minutes: Double? { preset == 0 ? Double(customMinutes.replacingOccurrences(of: ",", with: ".")) : Double(preset) }
    // Use the chosen activity, or trimmed custom text for Other.
    private var label: String { (activity == "Other" ? customActivity : activity).trimmingCharacters(in: .whitespacesAndNewlines) }
    // Require a finite 1–120 minute duration and a nonempty activity before starting.
    private var valid: Bool { minutes.map { $0.isFinite && (1...120).contains($0) } == true && !label.isEmpty }

    // Show pre-break ratings, duration presets/custom minutes and the Start break controls.
    var body: some View {
        ScrollView {
        VStack(alignment: .leading, spacing: 22) {
            Label("Make time for a break", systemImage: "leaf").font(.title2.weight(.semibold))
            if tracker.sessionSurveyOptions.beforeBreak {
                Text("Before you step away, a quick check-in.").foregroundStyle(.secondary)
                FatigueSlider(rating: $fatigue)
                RatingSlider(title: SurveyEntry.productivityQuestion,
                    low: "Not productive", high: "Extremely productive", rating: $productivity)
                Divider()
            }
            Text("Choose a duration and what you feel like doing.").foregroundStyle(.secondary)
            Picker("Duration", selection: $preset) {
                Text("5 min").tag(5)
                Text("10 min").tag(10)
                Text("15 min").tag(15)
                Text("Custom").tag(0)
            }.pickerStyle(.segmented)
            if preset == 0 {
                HStack {
                    TextField("Minutes", text: $customMinutes).textFieldStyle(.roundedBorder).frame(width: 90)
                    Text("minutes · 1–120").foregroundStyle(.secondary)
                }
            }
            BreakActivityPicker(selection: $activity, custom: $customActivity)
            Text("Detailed tracking pauses during your break. Use “I'm back” or return to another app to finish early.")
                .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            HStack {
                Button("Cancel") { dismiss() }.buttonPressFeedback().keyboardShortcut(.cancelAction)
                Spacer()
                Button("Start break") {
                    guard let minutes, valid else { return }
                    tracker.beginBreak(minutes: minutes, activity: label, fatigue: fatigue, productivity: productivity)
                }.buttonPressFeedback().buttonStyle(.borderedProminent).controlSize(.large)
                    .disabled(!valid || (tracker.sessionSurveyOptions.beforeBreak && (fatigue == nil || productivity == nil)))
            }
            if tracker.sessionSurveyOptions.beforeBreak {
                Button("Skip ratings & start break") {
                    guard let minutes, valid else { return }
                    tracker.beginBreak(minutes: minutes, activity: label, fatigue: nil, productivity: nil)
                }.buttonPressFeedback().disabled(!valid).font(.callout)
            }
        }.padding(24)
            .background(GeometryReader { geometry in
                Color.clear.preference(key: BreakSetupHeightKey.self, value: geometry.size.height)
            })
        }
        .scrollBounceBehavior(.basedOnSize)
        .frame(width: 440, height: min(contentHeight, 600))
        .onPreferenceChange(BreakSetupHeightKey.self) { height in
            if height > 0 { contentHeight = height }
        }
    }
}

private struct BreakSetupHeightKey: PreferenceKey {
    static let defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = max(value, nextValue()) }
}

struct BreakActivityEditor: View {
    @ObservedObject var tracker: ActivityTracker
    @Environment(\.dismiss) private var dismiss
    @State private var selectedID: String?
    @State private var activity = "Stretch"
    @State private var custom = ""
    private let teal = Color(red: 0.02, green: 0.60, blue: 0.54)

    private var selectedBreak: BreakRecord? {
        tracker.completedBreaks.first { $0.id == selectedID }
    }
    private var label: String {
        (activity == "Other" ? custom : activity).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Edit activity").font(.system(size: 28, weight: .bold, design: .rounded))
                Text("Choose a break from this session and update what you did.")
                    .foregroundStyle(.secondary)
            }
            ScrollView {
                VStack(spacing: 8) {
                    ForEach(Array(tracker.completedBreaks.enumerated()), id: \.element.id) { index, record in
                        Button { select(record) } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "leaf").foregroundStyle(teal)
                                    .frame(width: 32, height: 32)
                                    .background(teal.opacity(0.1), in: RoundedRectangle(cornerRadius: 10))
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Break \(index + 1) · \(record.actualActivity.isEmpty ? record.plannedActivity : record.actualActivity)")
                                        .font(.callout.weight(.semibold)).lineLimit(2)
                                    Text(durationText(record.actualSeconds ?? 0))
                                        .font(.caption).monospacedDigit().foregroundStyle(.secondary)
                                }
                                Spacer(minLength: 8)
                                Image(systemName: selectedID == record.id ? "checkmark.circle.fill" : "circle")
                                    .foregroundStyle(selectedID == record.id ? teal : Color.secondary)
                            }
                            .padding(12).frame(maxWidth: .infinity, alignment: .leading)
                            .background(selectedID == record.id ? teal.opacity(0.08) : Color.primary.opacity(0.035),
                                        in: RoundedRectangle(cornerRadius: 14))
                            .overlay(RoundedRectangle(cornerRadius: 14)
                                .strokeBorder(selectedID == record.id ? teal.opacity(0.4) : .clear))
                            .contentShape(RoundedRectangle(cornerRadius: 14))
                        }.buttonStyle(.plain).buttonPressFeedback()
                            .accessibilityAddTraits(selectedID == record.id ? .isSelected : [])
                    }
                }
            }.scrollBounceBehavior(.basedOnSize).frame(maxHeight: 240)
            if let record = selectedBreak {
                VStack(alignment: .leading, spacing: 12) {
                    Text("What did you do?").font(.headline)
                    Text("Planned: \(record.plannedActivity)").font(.caption).foregroundStyle(.secondary)
                    BreakActivityPicker(selection: $activity, custom: $custom)
                }.padding(16).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.primary.opacity(0.035), in: RoundedRectangle(cornerRadius: 16))
            } else {
                ContentUnavailableView("No completed breaks yet", systemImage: "leaf",
                    description: Text("Your breaks will appear here when you return."))
            }
            HStack {
                Button("Cancel") { dismiss() }.buttonPressFeedback().keyboardShortcut(.cancelAction)
                Spacer()
                Button("Save activity") {
                    guard let record = selectedBreak else { return }
                    tracker.confirmBreakActivity(label, breakID: record.id)
                    dismiss()
                }.buttonPressFeedback().buttonStyle(.borderedProminent).controlSize(.large)
                    .disabled(label.isEmpty || selectedBreak == nil || !tracker.isRecording)
            }
        }.padding(28).frame(width: 440).tint(teal)
            .onAppear { if let record = tracker.completedBreaks.last { select(record) } }
            .onChange(of: tracker.sessionFolder) { _, _ in dismiss() }
            .onChange(of: tracker.isRecording) { _, recording in if !recording { dismiss() } }
    }

    private func select(_ record: BreakRecord) {
        selectedID = record.id
        let value = record.actualActivity.isEmpty ? record.plannedActivity : record.actualActivity
        activity = BreakActivityPicker.options.contains(value) ? value : "Other"
        custom = activity == "Other" ? value : ""
    }
}

struct BreakControls: View {
    @ObservedObject var tracker: ActivityTracker
    var showsTakeBreak = true
    // Keep reminders here when the main action row offers Take a break.
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if tracker.breakPromptPending {
                Text("A moment for a break?").font(.headline)
                HStack {
                    if showsTakeBreak {
                        Button("Take a break") { tracker.chooseBreak() }.buttonPressFeedback().buttonStyle(.borderedProminent)
                    }
                    Button("Skip") { tracker.deferBreak(snooze: false) }.buttonPressFeedback().help("Wait 25 more minutes, then look for an idle moment")
                    Button("Snooze 10 min") { tracker.deferBreak(snooze: true) }.buttonPressFeedback()
                }
            } else if showsTakeBreak {
                HStack {
                    Spacer()
                    Button("Take a break") { tracker.chooseBreak() }.buttonPressFeedback()
                }
            }
            if let notice = tracker.notificationNotice {
                Text(notice).font(.caption).foregroundStyle(.secondary)
            }
        }
    }
}
