// MARK: - FF: UI
// Registers app windows, menu-bar controls, appearance and the once-per-launch opening animation.

import SwiftUI
import AppKit

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var progressTimer: Timer?
    func applicationDidFinishLaunching(_ notification: Notification) {
        progressTimer = Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { _ in
            Task { @MainActor in ActivityTracker.shared.reconcileProgress() }
        }
    }
    // Register notification actions before the app finishes launching.
    func applicationWillFinishLaunching(_ notification: Notification) {
        ActivityTracker.shared.configureNotifications()
    }
    // Keep FocusFix running in the menu bar after the last window closes.
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }
}

@main struct MyApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var delegate
    @StateObject private var tracker = ActivityTracker.shared
    @StateObject private var launch = LaunchCoordinator.shared
    @StateObject private var account = AccountController.shared
    // Instantiate the durable queue even when the user never opens Settings this launch.
    @StateObject private var research = ResearchSharingController.shared
    @StateObject private var development = DevelopmentSharingController.shared
    @State private var launchFinished = false
    @AppStorage("appearance") private var appearance = "system"
    // Translate System/Light/Dark preferences into SwiftUI's appearance setting.
    private var colorScheme: ColorScheme? {
        appearance == "dark" ? .dark : appearance == "light" ? .light : nil
    }
    // Create the main window, session/test windows and menu bar, applying the remembered appearance.
    var body: some Scene {
        Window("FocusFix", id: "collector") {
            CollectorRootView(tracker: tracker, launch: launch, account: account, launchFinished: $launchFinished)
                .preferredColorScheme(colorScheme)
                .onAppear { research.checkDue(); development.checkDue(); SocialController.shared.start(); tracker.reconcileProgress() }
        }.windowResizability(.contentSize)
        .commands { FocusFixCommands() }
        Window("About, privacy & support — FocusFix", id: "about") {
            AboutView().preferredColorScheme(colorScheme)
        }.defaultSize(width: 560, height: 650)
        Window("Sessions — FocusFix", id: "sessions") {
            SessionLibraryView(tracker: tracker).preferredColorScheme(colorScheme)
        }.defaultSize(width: 760, height: 520)
        Window("Groups — FocusFix", id: "groups") {
            GroupsView().preferredColorScheme(colorScheme)
        }.defaultSize(width: 620, height: 580)
        Window("Test tracking — FocusFix", id: "tracking") {
            TrackingTestView(tracker: tracker).preferredColorScheme(colorScheme)
        }.windowResizability(.contentSize)
        Settings { PrivacyResearchSettings().preferredColorScheme(colorScheme) }
        MenuBarExtra {
            RecordingMenu(tracker: tracker, launch: launch)
        } label: {
            Label(tracker.breakPhase != .work && tracker.isRecording ? "FocusFix on break" : tracker.isRecording ? "FocusFix recording" : "FocusFix",
                  systemImage: tracker.breakPhase != .work && tracker.isRecording ? "leaf.fill" : tracker.isRecording ? "record.circle.fill" : "pause.circle")
        }
    }
}

private struct RecordingMenu: View {
    @ObservedObject var tracker: ActivityTracker
    @ObservedObject var launch: LaunchCoordinator
    @Environment(\.openWindow) private var openWindow
    // Expose session, break and survey controls while the main window is closed.
    var body: some View {
        Text(tracker.recordingStatus)
        ProgressMenuSummary(tracker: tracker)
        Button("Groups") { openWindow(id: "groups"); NSApp.activate(ignoringOtherApps: true) }
        if tracker.isRecording, tracker.sessionWorkPlan.targetMinutes != nil {
            Text(tracker.sessionWorkPlan.summary)
            if tracker.sessionWorkPlan.isComplete {
                Text("Plan complete")
                if tracker.sessionWorkPlan.reminderPending {
                    Button("Keep going") { tracker.keepGoingAfterPlan() }
                }
            }
        }
        Button("Show FocusFix") {
            openWindow(id: "collector")
            NSApp.activate(ignoringOtherApps: true)
        }
        Button(tracker.isRecording && tracker.userContext == .work ? "End work" : "Start work") {
            if tracker.isRecording && tracker.userContext == .work { tracker.endWork() } else {
                launch.requestStart(start: { tracker.requestStart() }, showWindow: {
                    openWindow(id: "collector")
                    NSApp.activate(ignoringOtherApps: true)
                })
                if !tracker.isRecording {
                    openWindow(id: "collector")
                    NSApp.activate(ignoringOtherApps: true)
                }
            }
        }
        if tracker.isRecording {
            Text("Context · \(tracker.userContext == .work ? "Work" : tracker.userContext == .nonWork ? "Not working" : "Unknown")")
            Menu("Activity context") {
                Button("Work") { tracker.setContext(.work) }
                Button("Not working") { tracker.setContext(.nonWork) }
                Button("Unknown") { tracker.setContext(.unknown) }
            }
            Divider()
            if tracker.timedCheckInPending {
                Button("Answer check-in") {
                    openWindow(id: "collector")
                    NSApp.activate(ignoringOtherApps: true)
                    tracker.openTimedCheckIn()
                }
                Button("Skip check-in") { tracker.skipTimedCheckIn() }
                Divider()
            }
            if tracker.breakPhase != .work {
                Button("I'm back") { tracker.returnFromBreak() }
            } else {
                Button(tracker.breakPromptPending ? "Break suggested — take a break" : "Take a break") {
                    tracker.chooseBreak()
                    openWindow(id: "collector")
                    NSApp.activate(ignoringOtherApps: true)
                }.disabled(tracker.timedCheckInPresented)
                if tracker.breakPromptPending {
                    Button("Skip — wait 25 min") { tracker.deferBreak(snooze: false) }
                    Button("Snooze 10 min") { tracker.deferBreak(snooze: true) }
                }
            }
        }
        if !(tracker.isRecording && tracker.userContext == .work) {
            Button("Plan session…") {
                openWindow(id: "collector")
                NSApp.activate(ignoringOtherApps: true)
                tracker.requestPlannedStart()
            }
        }
        Button("Sessions") {
            openWindow(id: "sessions")
            NSApp.activate(ignoringOtherApps: true)
        }
        Divider()
        QuickTourButton()
        Button("About, privacy & support") {
            openWindow(id: "about")
            NSApp.activate(ignoringOtherApps: true)
        }
        Button("Quit FocusFix") {
            tracker.prepareToQuit()
            NSApp.terminate(nil)
        }.keyboardShortcut("q")
    }
}

private struct FocusFixCommands: Commands {
    @Environment(\.openWindow) private var openWindow
    var body: some Commands {
        CommandGroup(replacing: .appInfo) {
            Button("About FocusFix") { openWindow(id: "about") }
        }
        CommandGroup(replacing: .help) {
            QuickTourButton()
            Button("Privacy & support") { openWindow(id: "about") }
            Link("FocusFix support", destination: AppLinks.support)
        }
    }
}
