#!/bin/bash
# Synthetic data only. This never opens the app or reads saved participant sessions.
set -euo pipefail
cd "$(dirname "$0")/.."
test_build_dir=$(mktemp -d "${TMPDIR:-/tmp}/focusfix-tests.XXXXXX")
trap 'rm -rf -- "$test_build_dir"' EXIT
source_dir="FocusFix/FocusFix"

run_test() {
    local name="$1"
    shift
    if [[ -n "${FOCUSFIX_TEST_FILTER:-}" && ! "$name" =~ ^($FOCUSFIX_TEST_FILTER)$ ]]; then return; fi
    echo "Testing $name"
    local sources=("$source_dir/SessionTags.swift" "$source_dir/WorkAssignments.swift") candidate existing duplicate
    for candidate in "$source_dir/SessionStorage.swift" "$source_dir/DailyTimeline.swift" "$source_dir/SessionConditions.swift" "$source_dir/SessionTags.swift" "$source_dir/RecordingContract.swift" "$source_dir/ReminderEligibility.swift" "$source_dir/StudyCheckIns.swift" "$source_dir/ResearchArchiveContract.swift" "$source_dir/RecordingCoverage.swift" "$source_dir/SavedSession.swift" "$@"; do
        duplicate=false
        for existing in "${sources[@]}"; do if [ "$candidate" = "$existing" ]; then duplicate=true; break; fi; done
        if [ "$duplicate" = false ]; then sources+=("$candidate"); fi
    done
    xcrun swiftc -D FOCUSFIX_SYNTHETIC_TESTS -module-cache-path "$test_build_dir/module-cache" "${sources[@]}" "Tests/$name.swift" -o "$test_build_dir/$name"
    "$test_build_dir/$name"
}

run_test SessionStorageTests "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift" "$source_dir/DevelopmentSharing.swift"
run_test DailyExportSizeTests "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test DailyTimelineTests "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test ChecklistPageTests "$source_dir/ChecklistPage.swift"
run_test TaskPopupLayoutTests "$source_dir/TaskPopupLayout.swift"
run_test ChecklistReorderingTests "$source_dir/ChecklistReordering.swift"
run_test ProjectsTests "$source_dir/Projects.swift"
run_test WorkAssignmentsTests "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift" "$source_dir/DevelopmentSharing.swift"
run_test RetiredDailySurveyTests "$source_dir/StartOfDaySurvey.swift"
run_test AutomaticRecordingPreferencesTests "$source_dir/AutomaticRecordingPreferences.swift" "$source_dir/RecordingNotice.swift" "$source_dir/LoginLaunch.swift"
run_test RecordingLifecycleTests "$source_dir/SystemIdleTime.swift" "$source_dir/RecordingLifecycle.swift" "$source_dir/SavedSession.swift" "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test ContextEditingTests "$source_dir/SavedSession.swift" "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test ButtonPressGeometryTests "$source_dir/ButtonPressGeometry.swift"
run_test ReminderEligibilityTests
run_test RecordingCoverageTests "$source_dir/RecordingCoverage.swift" "$source_dir/RecordingPresentation.swift" "$source_dir/SavedSession.swift"
run_test StudyCheckInTests "$source_dir/SurveyPreferences.swift" "$source_dir/SurveyData.swift" "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/TimedCheckIn.swift"
run_test DeclaredWorkProgressTests "$source_dir/DailyProgress.swift" "$source_dir/SocialProgress.swift"
run_test ResearchArchiveContractTests "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test DevelopmentSharingTests "$source_dir/DevelopmentSharing.swift" "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test DevelopmentDeliveryTests "$source_dir/DevelopmentSharing.swift" "$source_dir/DevelopmentSharingController.swift" \
    "$source_dir/UserProfile.swift" "$source_dir/AccountAPI.swift" "$source_dir/AccountController.swift" \
    "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test SessionLibraryLoadingTests
run_test ExperimentalActivityPolicyTests "$source_dir/ExperimentalActivityPolicy.swift"
run_test AutomaticTrackingIntegrationTests "$source_dir/RecordingLifecycle.swift" "$source_dir/DailyProgress.swift" "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test RecordingContractTests
run_test SocialProgressTests "$source_dir/DailyProgress.swift" "$source_dir/SocialProgress.swift"
run_test SocialControllerTests "$source_dir/DailyProgress.swift" "$source_dir/SocialProgress.swift" \
    "$source_dir/SocialController.swift" "$source_dir/GroupPresentation.swift" "$source_dir/UserProfile.swift" "$source_dir/AccountAPI.swift" "$source_dir/AccountController.swift"
run_test SocialSyncScalingTests "$source_dir/DailyProgress.swift" "$source_dir/SocialProgress.swift" \
    "$source_dir/SocialController.swift" "$source_dir/GroupPresentation.swift" "$source_dir/UserProfile.swift" "$source_dir/AccountAPI.swift" "$source_dir/AccountController.swift"
run_test RecordingEfficiencyTests "$source_dir/DailyProgress.swift" "$source_dir/SocialProgress.swift" \
    "$source_dir/SocialController.swift" "$source_dir/GroupPresentation.swift" "$source_dir/UserProfile.swift" "$source_dir/AccountAPI.swift" "$source_dir/AccountController.swift"
run_test GroupPresentationTests "$source_dir/GroupPresentation.swift" "$source_dir/SocialProgress.swift" "$source_dir/DailyProgress.swift"
run_test QuickTourTests "$source_dir/QuickTour.swift" "$source_dir/GroupPresentation.swift" "$source_dir/SocialProgress.swift" "$source_dir/DailyProgress.swift"
run_test SessionWorkPlanTests "$source_dir/SessionWorkPlan.swift" "$source_dir/SessionStartDraft.swift" "$source_dir/DailyProgress.swift"
run_test SessionRetentionTests "$source_dir/SavedSession.swift" "$source_dir/DailyProgress.swift" \
    "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test SessionConditionsTests "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test SessionTagsTests "$source_dir/SavedSession.swift"
run_test LaunchCoordinatorTests "$source_dir/UserProfile.swift" "$source_dir/AccountAPI.swift" \
    "$source_dir/AccountController.swift" "$source_dir/LaunchCoordinator.swift"
run_test AccountTests "$source_dir/UserProfile.swift" "$source_dir/AccountAPI.swift" "$source_dir/AccountController.swift"
run_test ResearchDeliveryTests "$source_dir/UserProfile.swift" "$source_dir/AccountAPI.swift" "$source_dir/AccountController.swift" \
    "$source_dir/ResearchSharing.swift" "$source_dir/ResearchSharingController.swift" "$source_dir/SavedSession.swift"
run_test ResearchSharingTests "$source_dir/UserProfile.swift" "$source_dir/AccountAPI.swift" "$source_dir/ResearchSharing.swift"
run_test UserProfileTests "$source_dir/UserProfile.swift" "$source_dir/ProfileController.swift"
run_test BadgeControllerTests "Tests/BadgeTestSupport.swift" "$source_dir/Badges.swift" "$source_dir/BadgeController.swift" "$source_dir/DailyProgress.swift" "$source_dir/BreakNotifications.swift" "$source_dir/NotificationAccess.swift"
run_test BadgeSharingTests "$source_dir/LaunchScreen.swift" "$source_dir/Badges.swift" "$source_dir/DailyProgress.swift" "$source_dir/BadgeArtwork.swift" "$source_dir/BadgeSharing.swift"
run_test BadgeAwardsTests "$source_dir/Badges.swift" "$source_dir/DailyProgress.swift"
run_test DailyProgressTests "$source_dir/DailyProgress.swift" "$source_dir/BreakPolicy.swift" \
    "$source_dir/RecordingData.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test RecordingDataTests "$source_dir/RecordingData.swift" \
    "$source_dir/BreakPolicy.swift" "$source_dir/SavedSession.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test ExportContextTests "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test BreakPolicyTests "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test SurveyDataTests "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test TimedCheckInTests "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift" "$source_dir/SurveyData.swift" "$source_dir/TimedCheckIn.swift"
run_test NotificationAccessTests "$source_dir/NotificationAccess.swift"
run_test RecordingNoticeTests "$source_dir/RecordingNotice.swift"
run_test InputMonitorTests "$source_dir/InputMonitor.swift"
run_test SurveyPreferencesTests "$source_dir/SurveyPreferences.swift" "$source_dir/SurveyData.swift" \
    "$source_dir/TimedCheckIn.swift" "$source_dir/RecordingData.swift" "$source_dir/BreakPolicy.swift"
echo "All FocusFix tests passed."
