-- Synthetic regression fixtures; no user data survives this transaction.
begin;
do $$
declare
 a uuid := gen_random_uuid(); b uuid := gen_random_uuid(); g uuid := gen_random_uuid();
 result record; state jsonb; member jsonb; today date := (now() at time zone 'UTC')::date; last_work date;
begin
 insert into auth.users(id,email) values(a,'streak-a@example.invalid'),(b,'streak-b@example.invalid');
 insert into public.social_accounts(user_id,timezone,activated_at) values(a,'UTC','2026-01-01'),(b,'UTC','2026-01-01');
 insert into public.social_groups(id,owner,name) values(g,a,'Synthetic streak regression');
 insert into public.social_members(group_id,user_id,joined_at) values(g,a,'2026-10-19'),(g,b,'2026-10-19');
 insert into public.social_member_days(group_id,user_id,day,seconds) values(g,a,'2026-10-19',3600);
 select * into result from public.social_group_work_streak(a,g,'2026-10-19T16:00:00Z');
 if result.streak<>1 or result.frozen then raise exception 'Earned streak failed'; end if;
 select * into result from public.social_group_work_streak(a,g,'2026-10-21T16:00:00Z');
 if result.streak<>1 or not result.frozen then raise exception 'Single missed weekday not frozen'; end if;
 select * into result from public.social_group_work_streak(a,g,'2026-10-22T16:00:00Z');
 if result.streak<>0 or result.frozen then raise exception 'Consecutive missed weekdays did not break streak'; end if;
 insert into public.social_member_days(group_id,user_id,day,seconds) values(g,a,'2026-10-21',3600);
 select * into result from public.social_group_work_streak(a,g,'2026-10-21T16:00:00Z');
 if result.streak<>2 or result.frozen then raise exception 'New work did not thaw streak'; end if;
 -- An uncompleted weekend preserves the preceding protected Friday.
 insert into public.social_member_days(group_id,user_id,day,seconds) values(g,b,'2026-10-22',3600);
 select * into result from public.social_group_work_streak(b,g,'2026-10-26T16:00:00Z');
 if result.streak<>1 or not result.frozen then raise exception 'Weekend freeze failed'; end if;
 select * into result from public.social_group_work_streak(b,g,'2026-10-28T16:00:00Z');
 if result.streak<>0 or result.frozen then raise exception 'Missed Tuesday did not end frozen streak'; end if;
 -- Exhausting three freezes ends the streak on the next uncovered weekday.
 delete from public.social_member_days where group_id=g and user_id=b;
 insert into public.social_member_days(group_id,user_id,day,seconds)
  select g,b,d::date,3600 from unnest(array['2026-10-19','2026-10-21','2026-10-23','2026-10-27']) d;
 select * into result from public.social_group_work_streak(b,g,'2026-10-28T16:00:00Z');
 if result.streak<>4 or result.frozen then raise exception 'Today was prematurely broken or frozen'; end if;
 select * into result from public.social_group_work_streak(b,g,'2026-10-29T16:00:00Z');
 if result.streak<>0 or result.frozen then raise exception 'Monthly freeze limit exceeded'; end if;
 -- Late qualifying work thaws the last protected day without adding a freeze day.
 insert into public.social_member_days(group_id,user_id,day,seconds) values(g,b,'2026-10-26',3600);
 select * into result from public.social_group_work_streak(b,g,'2026-10-29T16:00:00Z');
 if result.streak<>5 or not result.frozen then raise exception 'Late work did not return the freeze token'; end if;
 -- Month refill cannot bypass the no-consecutive-date rule.
 delete from public.social_member_days where group_id=g;
 update public.social_members set joined_at='2026-09-29' where group_id=g;
 insert into public.social_member_days(group_id,user_id,day,seconds) values(g,a,'2026-09-29',3600);
 select * into result from public.social_group_work_streak(a,g,'2026-10-02T16:00:00Z');
 if result.streak<>0 then raise exception 'Month change incorrectly revived streak'; end if;
 -- The wrapper must rank an inactive member below an active member without
 -- requiring the inactive member to log in. Lifetime points remain untouched.
 delete from public.social_member_days where group_id=g;
 insert into public.social_member_days(group_id,user_id,day,seconds) values(g,a,'2026-01-01',3600);
 last_work:=today;
 while extract(isodow from last_work)>5 loop last_work:=last_work-1; end loop;
 insert into public.social_member_days(group_id,user_id,day,seconds) values(g,b,last_work,3600);
 perform set_config('request.jwt.claim.sub',a::text,true);
 state:=public.social_state('sync','{"timezone":"UTC"}');
 if (state->>'workStreakVersion')::int<>1 then raise exception 'Capability missing'; end if;
 select value into member from jsonb_array_elements(state->'groups'->0->'members') where value->>'id'=a::text;
 if (member->>'work')::int<>1 or (member->>'workStreak')::int<>0 or (member->>'workStreakRank')::int<>2 then raise exception 'Inactive member retained streak or rank'; end if;
 select value into member from jsonb_array_elements(state->'groups'->0->'members') where value->>'id'=b::text;
 if (member->>'workStreak')::int<>1 or (member->>'workStreakRank')::int<>1 then raise exception 'Current streak not ranked first'; end if;
 if has_function_privilege('authenticated','public.social_group_work_streak(uuid,uuid,timestamptz)','execute')
 or has_function_privilege('authenticated','public.social_state_daily_points(text,jsonb)','execute') then raise exception 'Private helper exposed'; end if;
end $$;
-- Weekend qualifications apply independently to work and healthy habits.
do $$
declare a uuid:=gen_random_uuid(); g uuid:=gen_random_uuid(); result record; saturday date;
begin
 insert into auth.users(id,email) values(a,'weekend-streak@example.invalid');
 insert into public.social_accounts(user_id,timezone,activated_at) values(a,'America/New_York','2026-10-22');
 insert into public.social_groups(id,owner,name) values(g,a,'Weekend streaks');
 insert into public.social_members(group_id,user_id,joined_at) values(g,a,'2026-10-22T12:00Z');
 -- Weekend work still needs 60 minutes, independently of healthy-habit credit.
 insert into public.social_member_days(group_id,user_id,day,seconds,healthy)
 values(g,a,'2026-10-22',3600,true),(g,a,'2026-10-24',3599,true);
 select * into result from public.social_group_work_streak(a,g,'2026-10-24T16:00Z');
 if result.streak<>1 or not result.frozen then raise exception 'Partial weekend work earned a day'; end if;
 select * into result from public.social_group_habit_streak(a,g,'2026-10-24T16:00Z');
 if result.streak<>2 or result.frozen then raise exception 'Weekend habit depended on work goal'; end if;
 update public.social_member_days set seconds=3600,healthy=false where group_id=g and day='2026-10-24';
 select * into result from public.social_group_work_streak(a,g,'2026-10-24T16:00Z');
 if result.streak<>2 or result.frozen then raise exception 'Exact weekend work goal did not count'; end if;
 select * into result from public.social_group_habit_streak(a,g,'2026-10-24T16:00Z');
 if result.streak<>1 or not result.frozen then raise exception 'Weekend work earned a habit day'; end if;
 delete from public.social_member_days where group_id=g;
 insert into public.social_member_days(group_id,user_id,day,seconds,healthy) values(g,a,'2026-10-22',3600,true),(g,a,'2026-10-24',7200,true);
 -- Saturday thaws Friday; an idle Sunday stays optional, using the scoring timezone.
 for result in select * from public.social_group_work_streak(a,g,'2026-10-26T03:30Z')
  union all select * from public.social_group_habit_streak(a,g,'2026-10-26T03:30Z') loop
  if result.streak<>2 or result.frozen then raise exception 'Saturday missing or idle Sunday hid thaw'; end if;
 end loop;
 insert into public.social_member_days(group_id,user_id,day,seconds,healthy) values(g,a,'2026-10-25',3600,true);
 for result in select * from public.social_group_work_streak(a,g,'2026-10-26T03:30Z')
  union all select * from public.social_group_habit_streak(a,g,'2026-10-26T03:30Z') loop
  if result.streak<>3 or result.frozen then raise exception 'Sunday did not add a day'; end if;
 end loop;
 -- A weekend can start a streak after missed weekdays, with normal Monday protection.
 delete from public.social_member_days where group_id=g and day<'2026-10-24';
 for result in select * from public.social_group_work_streak(a,g,'2026-10-27T16:00Z')
  union all select * from public.social_group_habit_streak(a,g,'2026-10-27T16:00Z') loop
  if result.streak<>2 or not result.frozen then raise exception 'Weekend-start streak did not protect Monday'; end if;
 end loop;
 for result in select * from public.social_group_work_streak(a,g,'2026-10-28T16:00Z')
  union all select * from public.social_group_habit_streak(a,g,'2026-10-28T16:00Z') loop
  if result.streak<>0 or result.frozen then raise exception 'Weekend credit bypassed missed-weekday reset'; end if;
 end loop;
 -- Account-wide freeze reconciliation must recognize weekend starts as well.
 saturday:=((now() at time zone 'America/New_York')::date-extract(isodow from now() at time zone 'America/New_York')::int)-8;
 update public.social_accounts set activated_at=saturday::timestamp at time zone 'America/New_York' where user_id=a;
 insert into public.social_days(user_id,day,seconds) values(a,saturday,3600);
 perform set_config('request.jwt.claim.sub',a::text,true);
 perform public.social_state('sync','{"timezone":"America/New_York"}');
 if not (select saturday+2=any(frozen) from public.social_accounts where user_id=a) then
  raise exception 'Account-wide ledger ignored weekend start'; end if;
 if has_function_privilege('authenticated','public.social_group_habit_streak(uuid,uuid,timestamptz)','execute') then
  raise exception 'Habit helper exposed'; end if;
 perform set_config('focusfix.current_streak_checks_passed','true',true);
end $$;
-- The marker is set only after all assertions. Running this SELECT alone cannot pass.
select current_setting('focusfix.current_streak_checks_passed',true)='true' as current_streak_regressions_passed;
rollback;
