# Local recording contract — schema 12

## Compact local storage and daily export schema

Local storage version 1 is separate from recording schema 12. Finalized recordings, including supported legacy schemas 1–11, may be represented by `storage.json` plus its named `recording-UUID.zip`. The index records each original file’s size and SHA-256 and caches session/context/eligibility bytes for history listings. Compression preserves every original byte. A synchronized adapter serves both representations, streams checked decompression to private temporary files, and supplies existing hosted archive allowlists without changing consent or research qualification gates.

ZIP creation and complete decompression/hash verification finish before the atomic index becomes authoritative. Only then may original files be removed. A failure before that point retains originals; interrupted cleanup is verified and retried. Metadata edits build and verify a replacement archive before swapping its index. Unfinished/unreadable recordings and conversions without a net saving retain their existing storage. Capture/checkpoint ordering and recovery bounds are unchanged. Startup compacts completed history in the background; finalization and rotation schedule new recordings.

User-facing exports now use `focusfix.daily_tables.v3`. Each date folder has at most five nonempty tables: inputs, movement, breaks, checkins and changes. `sessions.csv` stores short session references, original identifiers, UTC start anchors, logical origins, durable bounds and session status; `metadata.json` stores identity/protocol lookups, source schemas, remaining fields, revisions and precise JSON log details. One timezone captured at export start determines date grouping. Within each table rows sort by anchored UTC, session, logical elapsed and source order; simultaneous events remain distinct. Movement bounds are rounded on their one source row; other interval bounds remain unchanged. Cross-day references stay in metadata.

CSV source descriptors retain headers for retained fields and map each source column either to a narrow table column or a constant/lookup. Identifier maps are consistent across breaks, answers and prompts; `identity_csv_fields` declares the lookup domain for each original CSV identifier column. Optional source `order` arrays map chronological rows back to original record order only when needed. JSON documents/logs use scalar `moves` into sessions/changes rows and `remaining_json` for other fields; collection/log record lists preserve source order. JSON numeric lexemes are parsed without binary floating-point conversion. Spreadsheet-protection apostrophes have a sparse `escaped_cells` inverse map. Retained values remain reconstructable; intentionally removed fields and decimal precision, and redundant CSV/JSON formatting, are not preserved.

Inputs and movement omit `activity_phase` and `seconds_since_last_break`. Inputs keep repeat, hold and scroll-precision measurements unchanged. Movement start/end are nearest whole seconds; since-movement is at most two decimals. Rounding uses decimal text with ties away from zero, trims trailing decimal zeros, and preserves blank versus zero. Every movement row remains, including equal rounded bounds. Historical daily grouping, sorting and cross-day references use original timestamps before rounding; new recordings use the rounded measurement timestamps they recorded. Other numeric fields lose only redundant trailing zeros. No omitted field values or discarded movement decimals are copied into metadata. Nulls/missing JSON values remain distinct from empty strings. Durable bounds do not imply complete observation, and raw checkpoint tails remain without credit. No summary, ZIP or live secondary CSV copy is generated.

New recordings declare schema 12, `focusfix.recording.v12`, and the additional `observed_coverage_v1` and `reduced_movement_precision_v1` capabilities. Their input CSV has seven fields and movement CSV five, retaining existing raw column names except the two omissions. Measurement intervals stay at their existing sampling cadence. The exact in-memory movement intervals and intervention phases are coalesced into `observed_coverage.json`: `{ "version": 1, "intervals": [[start, end, "normal"], ...] }`. Only exactly adjacent intervals with the same phase merge; gaps remain unavailable. The sidecar is atomically replaced and synchronized after measurement bytes, before advancing the context checkpoint or finalizing. Readers validate interval order/bounds and clip tails at durable bounds. Missing or malformed schema 12 coverage raises an error rather than falling back to rounded measurements. Live calculations remain exact. Daily exports retain this sidecar once as a document in metadata.

Schema 11 contracts, metadata and crash recovery remain supported with their original capability set; their coverage reader continues to use original movement bounds/phases. Existing recordings are not converted to schema 12. Lossless archive compression remains separate and preserves the bytes of either schema. Hosted archive allowlists and delivery qualification gates are unchanged; backend analysis remains out of scope.

The retired start-of-day survey has no prompts/settings/export UI. Startup removes its saved local responses and two preferences, retrying failures. Timed session check-ins are unaffected.

The historical sections below describe schema 11 and original-format compatibility exports; the schema 12 reductions above supersede their measurement/coverage layout, and v3 daily tables supersede their copying layout and context normalization.

## Current controls and local exports

The current UI offers only Work and Unknown through Start work / End work
(including planned-session and menu-bar equivalents). Manual recording starts as
Work and ends on End work; automatic recording starts Unknown and returns to
Unknown on End work. Manual context selection, history corrections, and the
Not working notification action have been removed. Break intervention phases are
unchanged. Legacy `non_work` remains decodable for stored history.

Local single, selected, and all-session exports map legacy `non_work` to `unknown`
only in activity-context fields in context intervals, previous revision intervals,
reminder requests, and study check-in prompts. Export notes disclose the mapping.
Original recordings, IDs, timestamps, unrelated text, and CSV bytes are unchanged;
normalization failures remove incomplete exports. Hosted uploads are unchanged.
The historical implementation steps below document the original schema and APIs;
references to context controls and history editing describe the earlier UI.

I separate recording mode (manual/automatic), capture state (disabled, ready,
recording, user-paused, idle-paused, permission-unavailable), activity context
(work, non_work, unknown) and intervention phase (normal, explicit_break,
check_in, awaiting_return). Reasons describe unavailable/paused state. Work is a
user declaration, not verified productivity. Unknown is not non-work; a break is
an intervention, not a context label.

`session.json` declares `schema_version=11`, `recording_format=focusfix.recording.v11`,
required capabilities, recording/segment UUIDs, recording mode and the context file.
A compatible reader must check all capabilities and reject unsupported versions.
The separate atomic `context_intervals.json` is the authoritative label snapshot.
Each interval has a unique ID, a logical continuity ID, context, source, UTC
effective/action-recorded times (numeric Unix UTC seconds, preserving subsecond action timing) and `[start,end)` elapsed seconds. Only the final
interval of an unfinished recording can have a null end. Bounds must be finite,
nonnegative, within observed coverage and nonoverlapping. Empty completed recordings
have no intervals. `observedThrough` bounds the snapshot; final metadata duration
must match it. Elapsed times use the existing continuous monotonic clock, never
wall-clock differences. UTC timestamps order actions; timezone/clock changes do
not determine duration. Recorded end UTC remains start plus elapsed in the legacy
metadata, a derived ordering anchor rather than a sampled wall-clock end.

Manual Start declares work. Automatic recordings will begin unknown. The CSV
`activity_phase=work` still means the old normal intervention phase. It must never
be used as a work-context label. Schemas 1–10 stay unchanged and load as legacy/
unknown context; whole-session tags are not interval-level explicit declarations.
The event and mouse CSV columns and export copying remain unchanged. Label saves
replace the context snapshot atomically, without rewriting activity files.

The context snapshot reserves ordered revisions for bounded history corrections.
Automatic capture, consent, lifecycle, editing and UI integration follow in later
steps. This contract alone does not enable automatic recording.

## Research boundary

New-schema recordings are local only. Both completed-session queueing and archive
construction reject schema 11; old archives remain supported. Step 9 must explicitly
review the allowlist for `context_intervals.json`, all required capabilities,
provenance/revisions and any future coverage/check-in files. Old consent must not
cover new automatic/non-work data. Increasing ZIP limits cannot bypass daily study
caps. These changes do not enable research or establish study approval.

## Step 3: file segments and durable coverage

Rotation keeps one logical recording clock. A segment's `elapsed_origin_seconds`
(and context `elapsedOrigin`) is its start on that clock. CSV elapsed values and
label bounds stay on the logical clock; segment duration is observedThrough minus
origin. Recording ID and an active label's logical ID survive rotation; segment
IDs change. Break-policy timing and cooldown do not reset. UTC segment start is
sampled separately; timezone changes may trigger a new segment without changing
elapsed bounds. This avoids negative/overlapping elapsed intervals after clock edits.

Each sampling tick synchronizes event/mouse bytes before atomically checkpointing
`observedThrough`. After interruption, recovery finalizes only that checkpoint,
keeps raw bytes intact and marks any uncheckpointed tail ineligible. There is no
attempt to infer activity between the checkpoint and restart. A run-loop sampling
gap over five seconds closes capture at its last observation rather than generating
stationary bins across the gap. Automatic recordings, including short ones, are
retained. Unknown computer use is not credited to work goals.

One controller evaluates recording consent, automatic scope, durable user pause,
permission availability, sleep/display/login blockers, idle, failure and quit.
Idle cutoff defaults to 300 continuous seconds; idle resume reads the public OS
idle counter and does not install a second logger. Lifecycle resume creates a new
unknown recording. Failures require deliberate Resume/Start to retry. Actual
sleep/wake/lock, permission delivery and long-run resource use remain manual checks.

## Step 4: context actions and corrections

Start work on an existing automatic recording changes context from that action
forward, with one tap/writer. End work returns automatic activity to unknown;
manual-only End work saves/stops capture. Work, Not working and Unknown are
available in the menu. Repeated Start work preserves the existing logical work ID.
Labels survive rotation and ordinary app switching; idle, lifecycle/user pause and
End work clear active intent. Break phase remains independent of work intention.

The history editor accepts a bounded interval in segment-relative seconds, then
converts it to the logical elapsed origin. It checks the latest revision before
saving. The atomic snapshot contains ordered revisions with original intervals,
source/effective/action-recorded times (numeric Unix UTC seconds, preserving subsecond action timing) and idempotent correction IDs. Invalid or
stale edits leave the snapshot and raw files untouched. The snapshot is capped at
16 MiB; a size failure retains the previous readable labels. Legacy labels/files
are unchanged and cannot be assigned invented historical context by this path.

## Step 5: honest reminder requests

`reminders.jsonl` is append-only scheduled/requested/action history, including the
logical recording, context/work-period IDs, policy version, context, elapsed
schedule/action and UTC request/action-recorded times. Requested does not mean
delivered/viewed. An unanswered notification adds no rating, context confirmation
or break-completion evidence. This file must be reviewed in Step 9's allowlist.

The shipped policy remains the 25-minute/two-idle-gap baseline, eligible only for
declared work by default. A separate screen-use reminder preference includes
unknown/non-work without treating it as work. Notification Not working changes
context forward from the action and leaves capture running; history edits are
separate. Context/pause/revoke changes invalidate pending requests. Consumed
requests cannot be applied twice. Logical IDs and a process-monotonic cooldown
survive file rotation, avoiding stacked requests.

## Step 6: coverage in history

Recording files/segments are distinct from logical user work periods. History
calculates declared work, non-work and unknown only where mouse-summary coverage
was observed in normal intervention phase. Zero-movement observed bins count as
coverage; absent bins do not. Explicit break intervals come from break lifecycle
records, including continued breaks across segments. Check-in/awaiting-return
coverage is shown separately, and remaining duration is unavailable. No keyboard
capture completeness is implied by mouse coverage; Secure Input limitations remain.
Overlapping/malformed coverage fails closed instead of inflating durations.

Selected history coverage is computed off the main actor with a per-file read
limit. Legacy recordings retain unknown context. Local deletion, exports and
research deletion keep their separate meanings. The main status and menu use one
pure presentation function. The tour's automatic/label/pause controls modify only
its in-memory practice model, never the real tracker, consent, permissions or cloud.

## Step 7: optional study measurement, ordinary use survey-free

The original survey switches and answers remain intact, but an independent new
study-check-in opt-in (version, accepted scope and action UTC) is required. Old
preferences/research sharing do not activate it. With no complete reviewed bundled
configuration, live snapshots disable every survey. The repository supplies no
reviewed configuration. A synthetic configuration is accepted only through an
explicit isolated test injection. Real approval/consent terms are not fabricated.

A configuration names its review reference, consent scope, frozen schedule version,
spacing, recall window, rolling-24-hour cap and quiet local hours. The stored rate
budget survives relaunch; malformed state fails closed. Ordinary automatic/manual
starts and break flows require no ratings. Explicit study revocation immediately
cancels pending opportunities. Enabling/options changes wait for a new recording.

`study_check_ins.jsonl` joins immutable check-in IDs to activity context at request,
schedule/scope, recording ID and preceding recall bounds. End of recall is request
time, before opening/answering; check-in interaction is never preceding predictor
data. The existing survey/prompt CSVs retain their original meanings and blank
skip/cancel values. Separate logs distinguish requested/opened/answered/skipped/
cancelled/withdrawn; requests are not proof of delivery. The new file will require
Step 9 allowlist/scope review. The old work-only supervised backend rejects schema
11 and cannot consume cross-context study checks without a new adapter/evaluation.

## Step 8: declared-work progress

Live work credit comes only from completed mouse-summary slices intersecting declared
work in normal phase, after raw bytes are synchronized. Stationary observed bins
are included; gaps, check-ins, awaiting return and explicit breaks are excluded.
Segment day allocations use a captured scoring timezone and monotonic durations.
The local progress ledger's additive version 2 stores replaceable segment allocations
and revision counts alongside the protected legacy baseline. Reconciliation detects
changed labels or recovered segments and replaces contributions idempotently.

Social replacement summaries are captured only under the matching signed-in,
opted-in account/origin and retained separately from legacy increment events. The
old RPC cannot reconcile decreases: new work sync fails closed. Existing group
scores/thresholds/freezes and explicit-break rules are unchanged. See
`supabase/DECLARED-WORK-SYNC.md` for the required server capability before release.

## Step 9: prepared archive version 2, delivery still disabled

`research_eligibility.json` is a private local snapshot of the segment's account/
consent identity and scope (or local-only nil). It contains no credentials and is
excluded from research ZIPs. Explicit user folder exports can include this local
pseudonymous consent reference. A versioned research scope must separately cover
automatic/non-work capture, context/revisions, optional checks, retention/deletion
and training uses; old consent decodes with no such scope and fails closed.

The prepared allowlist adds context, reminder and study-check logs to the existing
six files. Metadata/capabilities and snapshot IDs must match, capture must begin
after consent, and the active identity must still match. Daily cap remains 180
minutes; 100 MiB raw/25 MiB ZIP limits remain deliberate. Oversized whole segments
stay local. The new ZIP builder is test-flag-only and marked-generated-fixture-only.
Shipping delivery qualification is a constant false, and the original live queue
continues to reject schema 11. Reviewed configuration and disposable-service end-to-
end checks, including cumulative server caps/races, are still release dependencies.


## Final compatibility/qualification audit

Earlier local v11 snapshots with ISO UTC dates and omitted elapsed origin/scoring
zone load without rewriting: missing origin is zero, unknown historical scoring
zone defaults to UTC. Current snapshots use numeric Unix UTC dates and an explicit
zone. Malformed new metadata or a context sidecar attached to legacy metadata is
never silently accepted as an older format. Unreadable/unsupported folders stay on
disk and are reported while compatible history remains available; Export All fails
closed for such folders. Readable export folder names do not change stored identity.

The idle reader uses Apple's any-input token, not a null-event query. Missing idle
status is not zero activity. Pending OS login approval can be turned off explicitly.
Fresh signed-device/system/accessibility and service qualification remain separate
from generated tests and component previews; see the readiness/manual checklists.

## Session conditions

`session.json` may include a `conditions` array. Each entry contains `categoryID`, `labelID` (UUID strings), and `category`, `label` (display-name snapshots). A category has at most one selected label; missing conditions mean an empty selection for older recordings. Names use the session label limits of 1–40 characters; up to 20 categories can be selected. Conditions apply to the entire segment and are not interval-level context declarations or inferred location/music observations.

The separate local `session-conditions.json` catalog holds reusable categories and labels with stable IDs. Editing that catalog does not modify saved session snapshots. Segment rotation carries conditions forward; new work starts empty unless conditions are explicitly supplied. History edits preserve other metadata. Exports and eligible sharing archives include condition snapshots as part of `session.json`.

## Private projects and task attribution

The local `projects.json` catalog stores stable project/task UUIDs, display names, project hex colors, canonical task order, and completion timestamps. Optional `lastWorkedAt` and `builtIn` fields preserve compatibility with older catalogs. Exactly one protected built-in folder keeps the name Random Tasks; migration adopts an existing folder of that name without changing its UUID or inserts a default folder. Its color/tasks remain editable. The persisted project array determines display order: a successful explicit work action records `lastWorkedAt` and promotes that project to the front, while manual moves rewrite the array without changing work timestamps. Opening, editing, completion, and automatic assignment reconciliation do not promote projects; manual order persists until a later work action. Completion never changes canonical order. Optional `completedTaskOrder` UUID arrays retain manual placement within the completed footer; catalogs without this field fall back to completion timestamps. New completions append to that footer, reopening removes its footer entry, and manual task moves update the canonical restoration slot as well. Drag/drop stays within the unfinished or completed section and never changes completion state. New work uses projects instead of tags; legacy `tags` and `tag_colors` remain decodable without migration.

Each new recording also has a private optional `work_assignments.json` sidecar. Its `changes` entries contain monotonic logical `elapsed` values and frozen assignment snapshots (`projectID`, `projectName`, `projectColor`, `taskID`, `taskTitle`). Missing project fields mean no project; a project with no task means Untasked Work. `breaks` stores break IDs and logical start/end bounds. Assignment changes checkpoint raw recording data before atomically saving the sidecar. Same-time choices replace the preceding same-time choice; identical choices are no-ops.

Readers intersect choices with the segment's `[elapsedOrigin, observedThrough]`, Work context intervals, and observed normal-phase work coverage. Breaks, check-ins, awaiting return, Unknown context, missing observations, and uncheckpointed tails receive no task credit. Segment rotation carries the active choice forward at the new logical origin. Project/task catalog edits never rewrite historical snapshots. Completing/deleting the active task starts Untasked Work from that action; deleting its project starts no-project work. Unchecking a task changes only its checklist state.

Original-format compatibility exports include the sidecar. Narrow daily exports distribute its recorded fields between changes.csv and metadata.json. It is deliberately absent from development/research upload allowlists, and project/task names must never be added to `session.json`, shared social-progress data, or research manifests. The catalog is not a recording archive member. Missing sidecars are valid for older recordings; unreadable sidecars retain their original bytes and show an assignment-history error without preventing access to the recording. These optional private files add no required recording capability and do not change schema 11.
