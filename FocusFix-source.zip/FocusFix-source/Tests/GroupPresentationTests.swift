import Foundation
import CoreGraphics

@main struct GroupPresentationTests {
    static func member(_ name: String, work: Int, habits: Int, workRank: Int, habitsRank: Int) -> SocialMember {
        SocialMember(id: UUID(), name: name, symbol: "leaf.fill", color: "teal", work: work, habits: habits, workRank: workRank, habitsRank: habitsRank, habitsStreak: habits, habitsStreakRank: habitsRank, workStreak: work, workStreakRank: workRank, workStreakFrozen: false)
    }
    static func main() throws {
        let alex = member("Alex", work: 8, habits: 2, workRank: 1, habitsRank: 3)
        let sam = member("Sam", work: 6, habits: 5, workRank: 2, habitsRank: 1)
        let jordan = member("Jordan", work: 6, habits: 4, workRank: 2, habitsRank: 2)
        let zero = member("Zero", work: 0, habits: 0, workRank: 4, habitsRank: 4)
        precondition(LeaderboardMetric.work.sorted([sam,zero,alex,jordan]).map(\.name) == ["Alex","Jordan","Sam","Zero"])
        precondition(LeaderboardMetric.habits.sorted([sam,zero,alex,jordan]).map(\.name) == ["Sam","Jordan","Alex","Zero"])
        precondition(PodiumPlace(rank: 1, score: 0) == nil)
        precondition(PodiumPlace(rank: 4, score: 3) == nil)
        precondition(PodiumPlace(rank: 2, score: 6) == .second)
        precondition(PodiumPlace(rank: 2, score: 6) == PodiumPlace(rank: LeaderboardMetric.work.rank(jordan), score: jordan.work))
        precondition(PodiumPlace(rank: LeaderboardMetric.habits.rank(alex), score: alex.habits) == .third)
        // A large historical score must never outrank a current streak after a break.
        let lost = SocialMember(id: UUID(), name: "Lost", symbol: "leaf", color: "teal", work: 100, habits: 0,
            workRank: 1, habitsRank: 1, workStreak: 0, workStreakRank: 2, workStreakFrozen: false)
        let live = SocialMember(id: UUID(), name: "Live", symbol: "leaf", color: "teal", work: 1, habits: 0,
            workRank: 2, habitsRank: 1, workStreak: 1, workStreakRank: 1, workStreakFrozen: true)
        precondition(LeaderboardMetric.work.sorted([lost,live]).map(\.name) == ["Live","Lost"])
        precondition(LeaderboardMetric.work.score(lost) == 0 && LeaderboardMetric.work.rank(live) == 1)
        let legacy = SocialMember(id: UUID(), name: "Old server", symbol: "leaf", color: "teal", work: 100, habits: 0, workRank: 1, habitsRank: 1)
        precondition(LeaderboardMetric.work.score(legacy) == 0 && legacy.workStreak == nil)
        let decoded = try JSONDecoder().decode(SocialMember.self, from: JSONEncoder().encode(live))
        precondition(decoded.workStreak == 1 && decoded.workStreakFrozen == true)
        let lostHabit = SocialMember(id: UUID(), name: "Lost habit", symbol: "leaf", color: "teal", work: 0, habits: 100,
            workRank: 1, habitsRank: 1, habitsStreak: 0, habitsStreakRank: 2)
        precondition(LeaderboardMetric.habits.score(lostHabit) == 0)
        precondition(LeaderboardMetric.habits.sorted([lostHabit, sam]).first?.id == sam.id)
        precondition(LeaderboardMetric.habits.score(legacy) == 0)
        let first = SocialGroup(id: UUID(), name: "First", owner: alex.id, code: nil, members: [alex])
        let second = SocialGroup(id: UUID(), name: "Second", owner: sam.id, code: nil, members: [sam])
        var selected = GroupSelection(groupID: second.id, metric: .habits)
        selected.reconcile(groups: [first,second]); precondition(selected.groupID == second.id)
        selected.reconcile(groups: [first]); precondition(selected.groupID == first.id && selected.metric == .habits)
        selected.reconcile(groups: []); precondition(selected.groupID == nil)
        let restored = try JSONDecoder().decode(GroupSelection.self, from: JSONEncoder().encode(selected))
        precondition(restored == selected && SocialGroup.capacity == 50)
        let states: [(Bool,Bool,Bool,Bool,Bool,Bool,GroupAccessState)] = [
            (false,true,false,true,false,false,.signedOut), (true,false,false,false,false,false,.disabled),
            (true,true,true,false,false,false,.loading), (true,true,false,true,false,false,.enabled),
            (true,true,false,true,true,true,.offline), (true,false,false,false,false,true,.unavailable)]
        for (signedIn,enabled,busy,loaded,failed,notice,expected) in states {
            precondition(GroupAccessState.resolve(signedIn: signedIn, enabled: enabled, busy: busy, loaded: loaded, failed: failed, notice: notice) == expected)
        }
        let screen = CGRect(x: -1440, y: 24, width: 1440, height: 876)
        precondition(PeopleWindowLayout.canExpand(in: screen))
        precondition(!PeopleWindowLayout.canExpand(in: CGRect(x:0,y:0,width:849,height:700)))
        let expanded = PeopleWindowLayout.clampedFrame(current: CGRect(x:-500,y:10,width:490,height:1000),expanded:true,visible:screen)
        precondition(screen.contains(expanded) && expanded.width == 850)
        let collapsed = PeopleWindowLayout.clampedFrame(current: expanded,expanded:false,visible:screen)
        precondition(collapsed.width == 490 && screen.contains(collapsed))
        let narrow = CGRect(x:0,y:0,width:700,height:600)
        precondition(narrow.contains(PeopleWindowLayout.clampedFrame(current:expanded,expanded:true,visible:narrow)))
        // Switching content reuses the same expansion width in either direction.
        var panels = CollectorPanelSelection()
        precondition(panels.expanded == nil && panels.sheet == nil)
        panels.toggle(.groups, canExpand: true)
        precondition(panels.expanded == .groups && panels.sheet == nil)
        for panel in [CollectorPanel.analytics, .groups, .analytics] {
            panels.toggle(panel, canExpand: true)
            precondition(panels.expanded == panel && panels.sheet == nil)
            let frame = PeopleWindowLayout.clampedFrame(current: expanded, expanded: panels.expanded != nil, visible: screen)
            precondition(frame.width == 850 && frame == expanded)
        }
        panels.toggle(.analytics, canExpand: true)
        precondition(panels.expanded == nil && panels.sheet == nil)
        panels.toggle(.analytics, canExpand: true)
        panels.adapt(canExpand: false)
        precondition(panels.expanded == nil && panels.sheet == .analytics)
        panels.toggle(.groups, canExpand: false)
        precondition(panels.expanded == nil && panels.sheet == .groups)
        panels.toggle(.groups, canExpand: false)
        precondition(panels.expanded == nil && panels.sheet == nil)
        panels.toggle(.analytics, canExpand: false)
        panels.close()
        precondition(panels.expanded == nil && panels.sheet == nil)
        panels.toggle(.groups, canExpand: true)
        panels.adapt(canExpand: true)
        precondition(panels.expanded == .groups)
        panels.close()
        precondition(panels.expanded == nil && panels.sheet == nil)
        print("Shared group selection, access states, tied and zero-score podium rules, and screen-clamped expansion passed")
    }
}
